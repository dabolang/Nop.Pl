from distutils.core import setup
setup(
    name='roddy',
    version='1.0.1',
    py_modules=['roddydef'],
    author='roddy',
    author_email='roddy@163.com',
    url='http://baidu.com',
    description='一个测试发布程序',
)