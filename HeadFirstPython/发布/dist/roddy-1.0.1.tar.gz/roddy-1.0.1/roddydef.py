def roddyprint(str):
    print('roddy se:'+str)